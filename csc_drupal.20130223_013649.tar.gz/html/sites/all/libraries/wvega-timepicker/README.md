jQuery TimePicker plugin
========================

A jQuery plugin to enhance standard form input fields helping users to select
(or type) times.

Plase visit http://wvega.github.com/timepicker/ for a more detailed list of features and options.