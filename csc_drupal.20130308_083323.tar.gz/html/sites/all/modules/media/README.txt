
/**
 *  @file
 *  README for the Media Module.
 */

See http://drupal.org/node/356802
